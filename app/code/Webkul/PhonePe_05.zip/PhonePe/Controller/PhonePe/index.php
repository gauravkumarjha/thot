<?php
/**
 * Webkul Software.
 *
 * @category  Webkul
 * @package   Webkul_PhonePe
 * @author    Webkul Software Private Limited
 * @copyright Webkul Software Private Limited (https://webkul.com)
 * @license   https://store.webkul.com/license.html
 */
namespace Webkul\PhonePe\Controller\PhonePe;

use Magento\Framework\App\Action\Action;
use Magento\Framework\App\Action\Context;
use PhonePe\payments\v2\standardCheckout\StandardCheckoutClient;
use PhonePe\payments\v2\models\request\builders\StandardCheckoutPayRequestBuilder;


class Index extends Action
{
    /**
     * @var \Webkul\PhonePe\Helper
     */
    protected $helper;
    /**
     * @var \Magento\Framework\UrlInterface
     */
    protected $urlBuilder;
    
    /**
     * @var \Magento\Framework\Controller\ResultFactory
     */
    protected $resultRedirect;

    /**
     * @var \Magento\Checkout\Model\Session
     */
    protected $checkoutSession;

    /**
     * @var \Magento\Directory\Model\CurrencyFactory
     */
    public $currencyFactory;

    /**
     * @var \Webkul\PhonePe\Logger\Logger
     */
    protected $logger;

    /**
     * @param Context $context
     * @param \Magento\Framework\UrlInterface $urlBuilder
     * @param \Magento\Framework\Controller\ResultFactory $result
     * @param \Magento\Checkout\Model\Session $checkoutSession
     * @param \Magento\Directory\Model\CurrencyFactory $currencyFactory
     * @param \Webkul\PhonePe\Logger\Logger $logger
     * @param \Webkul\PhonePe\Helper\Data $helper
     */
    public function __construct(
        Context $context,
        \Magento\Framework\UrlInterface $urlBuilder,
        \Magento\Framework\Controller\ResultFactory $result,
        \Magento\Checkout\Model\Session $checkoutSession,
        \Magento\Directory\Model\CurrencyFactory $currencyFactory,
        \Webkul\PhonePe\Logger\Logger $logger,
        \Webkul\PhonePe\Helper\Data $helper
    ) {
        $this->helper = $helper;
        $this->urlBuilder = $urlBuilder;
        $this->resultRedirect = $result;
        $this->checkoutSession = $checkoutSession;
        $this->currencyFactory = $currencyFactory;
        $this->logger = $logger;
        parent::__construct($context);
    }

    /**
     * Execute
     *
     * @return \Magento\Framework\Controller\Result\Redirect
     */
    public function execute()
    {
        /** @var Redirect $resultRedirect */
        $resultRedirect = $this->resultRedirect->create($this->resultRedirect::TYPE_REDIRECT);
        $this->logger->info('phone pe payment initialize executed ');
        try {
            $env = $this->helper->getEnv();
            $clientId = $this->helper->getConfigValue('client_id');
            $clientSecret = $this->helper->getConfigValue('client_secret');
            $clientVersion = $this->helper->getConfigValue('client_version');
            $phonePeClient = StandardCheckoutClient::getInstance(
                $clientId,
                $clientVersion,
                $clientSecret,
                $env
            );
            $quote = $this->checkoutSession->getQuote();
            $merchantTransactionId = "ORDER_" . time() . '_' .$quote->getId();
            $transactionId = $this->helper->encryptData($merchantTransactionId);
            $quoteId = $this->helper->encryptData($quote->getId());
            $queryParams = [
                'transactionId' => $transactionId,
                'quoteId' => $quoteId
            ];
            $redirectUrl = $this->urlBuilder->getUrl("phonepe/phonepe/returnaction", [
                '_current' => true,
                '_use_rewrite' => false,
                '_query' => $queryParams
            ]);
            $currencyCodeFrom = $quote->getQuoteCurrencyCode();
            $rate = $this->currencyFactory->create()
                    ->load($currencyCodeFrom)
                    ->getAnyRate('INR');
            $grandTotal = $quote->getGrandTotal();
            $price = ($rate * $grandTotal)*100;

            $request = StandardCheckoutPayRequestBuilder::builder()
                ->merchantOrderId($merchantTransactionId)
                ->amount($price)
                ->redirectUrl($redirectUrl)
                ->message('')
                ->build();
            $payResponse = $phonePeClient->pay($request);
            $this->logger->info('phone pe payment initialize response  :- '.json_encode($payResponse->jsonSerialize()));
            if ($payResponse->getState() === "PENDING") {
                $redirectUrl = $payResponse->getRedirectUrl();
                $resultRedirect->setUrl($redirectUrl);
            } else {
                $message = "Payment initiation failed: " . $payResponse->getState();
                $this->logger->info($message);
                $this->messageManager->addError(
                    __(
                        "There is an error in making payment with PhonePe payment method. Please contact the admin."
                    )
                );
                $resultRedirect->setUrl($this->urlBuilder->getUrl('checkout/cart/', ['_current' => false]));
                return $resultRedirect;
            }
        } catch (\PhonePe\common\exceptions\PhonePeException $e) {
            $this->logger->info($e->getMessage());
            $this->messageManager->addError(
                __(
                    "There is an error in making payment with PhonePe payment method. Please contact the admin."
                )
            );
            $resultRedirect->setUrl($this->urlBuilder->getUrl('checkout/cart/', ['_current' => false]));
            return $resultRedirect;
        } catch (\Exception $e) {
            $this->logger->info($e->getMessage());
            $this->messageManager->addError(
                __(
                    "There is an error in making payment with PhonePe payment method. Please contact the admin."
                )
            );
            $resultRedirect->setUrl($this->urlBuilder->getUrl('checkout/cart/', ['_current' => false]));
            return $resultRedirect;
        }
        return $resultRedirect;
    }
}
