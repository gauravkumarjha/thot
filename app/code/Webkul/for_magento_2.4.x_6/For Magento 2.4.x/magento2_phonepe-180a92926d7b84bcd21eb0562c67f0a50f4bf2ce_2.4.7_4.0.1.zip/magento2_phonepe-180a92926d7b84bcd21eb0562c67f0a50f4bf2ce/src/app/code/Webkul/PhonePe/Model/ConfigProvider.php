<?php

/**
 * Webkul Software.
 *
 * @category  Webkul
 * @package   Webkul_PhonePe
 * @author    Webkul Software Private Limited
 * @copyright Webkul Software Private Limited ( https://webkul.com )
 * @license   https://store.webkul.com/license.html
 */

namespace Webkul\PhonePe\Model;

use Magento\Checkout\Model\ConfigProviderInterface;
use Webkul\PhonePe\Model\PaymentMethod;

class ConfigProvider implements ConfigProviderInterface
{
    /**
     * @var \Webkul\PhonePe\Helper\Data
     */
    protected $helper;

    /**
     * @param \Webkul\PhonePe\Helper\Data $helper
     */
    public function __construct(
        \Webkul\PhonePe\Helper\Data $helper
    ) {
        $this->helper = $helper;
    }

    /**
     * Get configuration
     *
     * @return array
     */
    public function getConfig()
    {
        $isActive = $this->helper->getConfigValue('active');
        if (!$isActive) {
            return [];
        }
        $merchantId = $this->helper->getConfigValue('merchant_id');
        $saltKey = $this->helper->getConfigValue('salt_key');
        $saltIndex = $this->helper->getConfigValue('salt_index');
        $title = $this->helper->getConfigValue('title');
       
        return [
            'payment' => [
                PaymentMethod::METHOD_CODE => [
                    'isActive' => true,
                    'merchantId' => $merchantId,
                    'saltKey' => $saltKey,
                    'saltIndex' => $saltIndex,
                    'title' => $title,
                    'code' => PaymentMethod::METHOD_CODE
                ]
            ]
        ];
    }
}
