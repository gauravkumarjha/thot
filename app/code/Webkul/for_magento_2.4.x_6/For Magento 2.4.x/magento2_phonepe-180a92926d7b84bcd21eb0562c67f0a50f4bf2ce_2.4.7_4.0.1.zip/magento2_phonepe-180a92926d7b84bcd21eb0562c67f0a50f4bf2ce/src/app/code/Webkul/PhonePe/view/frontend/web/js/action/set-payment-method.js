/**
 * Webkul Software.
 *
 * @category   Webkul
 * @package    Webkul_PhonePe
 * @author     Webkul Software Private Limited
 * @copyright  Webkul Software Private Limited (https://webkul.com)
 * @license    https://store.webkul.com/license.html
 */
/*jshint jquery:true*/
define(
    [
        'jquery',
        'Magento_Checkout/js/model/quote',
        'Magento_Checkout/js/model/url-builder',
        'mage/storage',
        'Magento_Checkout/js/model/error-processor',
        'Magento_Customer/js/model/customer',
        'mage/url',
        'Magento_Checkout/js/model/full-screen-loader'
    ],
    function ($, quote, urlBuilder, storage, errorProcessor, customer, url, fullScreenLoader) {
        'use strict';
        return function (messageContainer) {
            var indexUrl = url.build('phonepe/phonepe/index');
            $.mage.redirect(indexUrl);
        };
    }
);
