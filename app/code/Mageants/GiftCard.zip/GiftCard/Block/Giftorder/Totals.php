<?php
/**
 * @category Mageants GiftCard
 * @package Mageants_GiftCard
 * @copyright Copyright (c) 2016 Mageants
 * @author Mageants Team <support@mageants.com>
 */

namespace Mageants\GiftCard\Block\Giftorder;

/**
 * Class GiftOrder Totals
 */
class Totals extends \Magento\Sales\Block\Order\Totals
{
}
