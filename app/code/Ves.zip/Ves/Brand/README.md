# module-brand
magento 2 Ves_Brand extension
Magento 2 Shop By Brand supports in creating individual & unique brand pages with brand logos, descriptions, and related products to showcase brand products separately.

Search, arrange, and filter products by brand and adding them to the layered navigation menu. Let's make it easy for customers to find their favorite products.
