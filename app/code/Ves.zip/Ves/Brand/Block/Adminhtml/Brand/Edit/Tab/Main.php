<?php
/**
 * Venustheme
 * 
 * NOTICE OF LICENSE
 * 
 * This source file is subject to the Venustheme.com license that is
 * available through the world-wide-web at this URL:
 * http://www.venustheme.com/license-agreement.html
 * 
 * DISCLAIMER
 * 
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 * 
 * @category   Venustheme
 * @package    Ves_Brand
 * @copyright  Copyright (c) 2014 Venustheme (http://www.venustheme.com/)
 * @license    http://www.venustheme.com/LICENSE-1.0.html
 */
namespace Ves\Brand\Block\Adminhtml\Brand\Edit\Tab;

class Main extends \Magento\Backend\Block\Widget\Form\Generic implements \Magento\Backend\Block\Widget\Tab\TabInterface
{
	/**
     * @var \Magento\Store\Model\System\Store
     */
    protected $_systemStore;

    /**
     * @var \Magento\Cms\Model\Wysiwyg\Config
     */
    protected $_wysiwygConfig;

    /**
     * @var \Ves\Brand\Helper\Data
     */
    protected $_viewHelper;

    /**
     * @param \Magento\Backend\Block\Template\Context $context       
     * @param \Magento\Framework\Registry             $registry      
     * @param \Magento\Framework\Data\FormFactory     $formFactory   
     * @param \Magento\Store\Model\System\Store       $systemStore   
     * @param \Magento\Cms\Model\Wysiwyg\Config       $wysiwygConfig 
     * @param \Ves\Brand\Helper\Data                  $viewHelper    
     * @param array                                   $data          
     */
    public function __construct(
        \Magento\Backend\Block\Template\Context $context,
        \Magento\Framework\Registry $registry,
        \Magento\Framework\Data\FormFactory $formFactory,
        \Magento\Store\Model\System\Store $systemStore,
        \Magento\Cms\Model\Wysiwyg\Config $wysiwygConfig,
        \Ves\Brand\Helper\Data $viewHelper,
        array $data = []
    ) {
        $this->_viewHelper = $viewHelper;
        $this->_systemStore = $systemStore;
        $this->_wysiwygConfig = $wysiwygConfig;
        parent::__construct($context, $registry, $formFactory, $data);
    }


    /**
     * Prepare form
     *
     * @return $this
     */
    protected function _prepareForm() {
    	/** @var $model \Ves\Brand\Model\Brand */
    	$model = $this->_coreRegistry->registry('ves_brand');
        
        $wysiwygConfig = $this->_wysiwygConfig->getConfig(['tab_id' => $this->getTabId()]);
    	/**
    	 * Checking if user have permission to save information
    	 */
    	if($this->_isAllowedAction('Ves_Brand::brand_edit')){
    		$isElementDisabled = false;
    	}else {
    		$isElementDisabled = true;
    	}
    	/** @var \Magento\Framework\Data\Form $form */
    	$form = $this->_formFactory->create();

    	$form->setHtmlIdPrefix('brand_');

    	$fieldset = $form->addFieldset('base_fieldset', ['legend' => __('Brand Information')]);


    	if ($model->getId()) {
    		$fieldset->addField('brand_id', 'hidden', ['name' => 'brand_id']);
    	}

    	$fieldset->addField(
    		'name',
    		'text',
    		[
                'name'     => 'name',
                'label'    => __('Brand Name'),
                'title'    => __('Brand Name'),
                'required' => true,
                'disabled' => $isElementDisabled
    		]
    		);

    	$fieldset->addField(
    		'url_key',
    		'text',
    		[
                'name'     => 'url_key',
                'label'    => __('URL Key'),
                'title'    => __('URL Key'),
                'note'     => __('Empty to auto create url key'),
                'disabled' => $isElementDisabled
    		]
    		);
        $fieldset->addField(
                'facebook_uri',
                'text',
                [
                    'name' => 'facebook_uri',
                    'label' => __('Facebook URL'),
                    'title' => __('Facebook URL'),
                    'required' => false,
                    'disabled' => $isElementDisabled
                ]
                );
            $fieldset->addField(
                'short_info',
                'text',
                [
                    'name' => 'short_info',
                    'label' => __('Short Info'),
                    'title' => __('Short Info'),
                    'required' => false,
                    'disabled' => $isElementDisabled
                ]
                );
            $fieldset->addField(
                'twitter_uri',
                'text',
                [
                    'name' => 'twitter_uri',
                    'label' => __('Twitter URL'),
                    'title' => __('Twitter URL'),
                    'required' => false,
                    'disabled' => $isElementDisabled
                ]
                );
            $fieldset->addField(
                'instagram_uri',
                'text',
                [
                    'name' => 'instagram_uri',
                    'label' => __('Instagram URL'),
                    'title' => __('Instagram URL'),
                    'required' => false,
                    'disabled' => $isElementDisabled
                ]
                );

        $fieldset->addField(
            'group_id',
            'select',
            [
                'label'    => __('Brand Group'),
                'title'    => __('Brand Group'),
                'name'     => 'group_id',
                'required' => true,
                'options'  => $this->_viewHelper->getGroupList(),
                'disabled' => $isElementDisabled
            ]
        );
        $fieldset->addField(
            'is_profile_layout',
            'select',
            [
                'label' => __('Profile layout'),
                'title' => __('Profile layout'),
                'name' => 'is_profile_layout',
                'options' => $model->getBrandLayout(),
                'disabled' => $isElementDisabled
            ]
        );

    	$fieldset->addField(
    		'image',
    		'image',
    		[
                'name'     => 'image',
                'label'    => __('Image'),
                'title'    => __('Image'),
                'disabled' => $isElementDisabled
    		]
    		);

    	$fieldset->addField(
    		'thumbnail',
    		'image',
    		[
                'name'     => 'thumbnail',
                'label'    => __('Thumbnail'),
                'title'    => __('Thumbnail'),
                'disabled' => $isElementDisabled
    		]
    		);
        $fieldset->addField(
                'brand_logo',
                'image',
                [
                    'name' => 'brand_logo',
                    'label' => __('Profile Pic/Logo'),
                    'title' => __('Profile Pic/Logo'),
                    'disabled' => $isElementDisabled,
                    'note'      => __('Profile image size should be 900 x 1160 and brand logo size should be 200 x 90')
                ]
                );

        $fieldset->addField(
            'image_one',
            'image',
            [
                'name' => 'image_one',
                'label' => __('Image one'),
                'title' => __('Image one'),
                'disabled' => $isElementDisabled,
                'note'      => __('Image size should be 700x470')
            ]
            );
        $fieldset->addField(
            'image_two',
            'image',
            [
                'name' => 'image_two',
                'label' => __('Image two'),
                'title' => __('Image two'),
                'disabled' => $isElementDisabled,
                'note'      => __('Image size should be 700x700')
            ]
            );
        $fieldset->addField(
            'image_three',
            'image',
            [
                'name' => 'image_three',
                'label' => __('Image three'),
                'title' => __('Image three'),
                'disabled' => $isElementDisabled,
                'note'      => __('Image size should be 700x700')
            ]
            );
        $fieldset->addField(
            'image_four',
            'image',
            [
                'name' => 'image_four',
                'label' => __('Image four'),
                'title' => __('Image four'),
                'disabled' => $isElementDisabled,
                'note'      => __('Image size should be 700x470')
            ]
            );
        $fieldset->addField(
            'image_five',
            'image',
            [
                'name' => 'image_five',
                'label' => __('Image five'),
                'title' => __('Image five'),
                'disabled' => $isElementDisabled,
                'note'      => __('Image size should be 700x470')
            ]
            );
            
            $fieldset->addField(
            'image_six',
            'image',
            [
                'name' => 'image_six',
                'label' => __('Image six'),
                'title' => __('Image six'),
                'disabled' => $isElementDisabled,
                'note'      => __('Image size should be 700x470')
            ]
            );
            
            $fieldset->addField(
            'image_seven',
            'image',
            [
                'name' => 'image_seven',
                'label' => __('Image seven'),
                'title' => __('Image seven'),
                'disabled' => $isElementDisabled,
                'note'      => __('Image size should be 700x700')
            ]
            );
            
            $fieldset->addField(
            'image_eight',
            'image',
            [
                'name' => 'image_eight',
                'label' => __('Image eight'),
                'title' => __('Image eight'),
                'disabled' => $isElementDisabled,
                'note'      => __('Image size should be 700x700')
            ]
            );

    	$fieldset->addField(
            'description',
            'editor',
            [
                'name'     => 'description',
                'style'    => 'height:200px;',
                'label'    => __('Description'),
                'title'    => __('Description'),
                'disabled' => $isElementDisabled,
                'config'   => $wysiwygConfig
            ]
        );
        $fieldset->addField(
                'edit_id',
                'text',
                [
                    'name' => 'edit_id',
                    'label' => __('Edit Id'),
                    'title' => __('Edit Id'),
                    'disabled' => $isElementDisabled,
                    'note'      => __('Use Edit id only ex: 12')
                ]
                );

    	/**
         * Check is single store mode
         */
        if (!$this->_storeManager->isSingleStoreMode()) {
            $field = $fieldset->addField(
                'store_id',
                'multiselect',
                [
                    'name' => 'stores[]',
                    'label' => __('Store View'),
                    'title' => __('Store View'),
                    'required' => true,
                    'values' => $this->_systemStore->getStoreValuesForForm(false, true),
                    'disabled' => $isElementDisabled
                ]
            );
            $renderer = $this->getLayout()->createBlock(
                'Magento\Backend\Block\Store\Switcher\Form\Renderer\Fieldset\Element'
            );
            $field->setRenderer($renderer);
        } else {
            $fieldset->addField(
                'store_id',
                'hidden',
                ['name' => 'stores[]', 'value' => $this->_storeManager->getStore(true)->getId()]
            );
            $model->setStoreId($this->_storeManager->getStore(true)->getId());
        }


        $fieldset->addField(
    		'position',
    		'text',
    		[
	    		'name' => 'position',
	    		'label' => __('Position'),
	    		'title' => __('Position'),
	    		'disabled' => $isElementDisabled
    		]
    		);
        
        if($this->_viewHelper->checkModuleInstalled("Lof_ShopByBrand")){
            $options1 = $this->_viewHelper->getAttributeOptions();

            $fieldset->addField(
                'attribute_id',
                'select',
                [
                    'name' => 'attribute_id',
                    'label' => __('Attribute Option'),
                    'title' => __('Attribute Option'),
                    'options'  => $options1,
                    'note' => __('The value was synced by module Lof_ShopByBrand (commerce version).'),
                    'disabled' => true
                ]
                );

            $options2 = $this->_viewHelper->getAttributeValueOptions();
            //array_unshift($options2, array(0=> __('-- Please Select --')));

            $fieldset->addField(
                'attribute_option_id',
                'select',
                [
                    'name' => 'attribute_option_id',
                    'label' => __('Attribute Option Value'),
                    'title' => __('Attribute Option Value'),
                    'options'  => $options2,
                    'note' => __('The value was synced by module Lof_ShopByBrand (commerce version).'),
                    'disabled' => true
                ]
                );
        }
        $fieldset->addField(
            'status',
            'select',
            [
                'label' => __('Status'),
                'title' => __('Page Status'),
                'name' => 'status',
                'options' => $model->getAvailableStatuses(),
                'disabled' => $isElementDisabled
            ]
        );
        $fieldset->addField(
            'featured',
            'select',
            [
                'label' => __('Is Featured'),
                'title' => __('Is Featured'),
                'name' => 'featured',
                'options' => $model->getAvailableStatuses(),
                'disabled' => $isElementDisabled
            ]
        );


    	$form->setValues($model->getData());
    	$this->setForm($form);

    	return parent::_prepareForm();
    }

    /**
     * Prepare label for tab
     *
     * @return \Magento\Framework\Phrase
     */
    public function getTabLabel()
    {
        return __('Brand Information');
    }

    /**
     * Prepare title for tab
     *
     * @return \Magento\Framework\Phrase
     */
    public function getTabTitle()
    {
        return __('Brand Information');
    }

    /**
     * {@inheritdoc}
     */
    public function canShowTab()
    {
        return true;
    }

    /**
     * {@inheritdoc}
     */
    public function isHidden()
    {
        return false;
    }

    /**
     * Check permission for passed action
     *
     * @param string $resourceId
     * @return bool
     */
    protected function _isAllowedAction($resourceId)
    {
        return $this->_authorization->isAllowed($resourceId);
    }
}