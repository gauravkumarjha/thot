# Magento 2 Theme 101

This repository showcases an example of a custom theme module for Magento 2.

## Installation

1. Clone the repository into the `app/code/design/frontend/MageMastery/custom` directory.

## Theme Activation

Follow the instructions in the [video](https://youtu.be/f-tkNRLxQrw).
