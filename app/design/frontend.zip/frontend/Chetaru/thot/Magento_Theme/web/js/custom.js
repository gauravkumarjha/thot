require(['jquery'], function($){
  "use strict";
   $(document).ready(function($)
 {
  // For sticky header
      $(window).scroll(function() {    
      var scroll = $(window).scrollTop();    
      if ($(document).scrollTop() > 50) {
        $("body").addClass("header-fixed");
      } else {
        $("body").removeClass("header-fixed");
      }
    });

  });
});