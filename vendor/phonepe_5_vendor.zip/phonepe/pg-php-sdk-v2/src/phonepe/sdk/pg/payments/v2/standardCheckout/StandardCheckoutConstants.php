<?php

namespace PhonePe\payments\v2\standardCheckout;

class StandardCheckoutConstants
{
	const STANDARD_CHECKOUT_PAY_API = "/checkout/v2/pay";
	const STANDARD_CHECKOUT_PAYMENT_FLOW_TYPE = "PG_CHECKOUT";
}