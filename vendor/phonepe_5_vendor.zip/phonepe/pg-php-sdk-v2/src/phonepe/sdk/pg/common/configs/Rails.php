<?php

namespace PhonePe\common\configs;

class Rails
{
	const UPI = "UPI";
	const PG = "PG";
	const PPI_WALLET = "PPI_WALLET";
	const PPI_EGV = "PPI_EGV";

}