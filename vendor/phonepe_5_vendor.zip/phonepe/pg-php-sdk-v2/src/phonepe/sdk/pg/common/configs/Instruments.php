<?php

namespace PhonePe\common\configs;

class Instruments
{
	const NET_BANKING = "NET_BANKING";
	const CREDIT_CARD = "CREDIT_CARD";
	const DEBIT_CARD = "DEBIT_CARD";
	const ACCOUNT = "ACCOUNT";
	const WALLET = "WALLET";
	const EGV = "EGV";
}